from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def hi(request):
    return render(request,'DEMOAPP/hi.html')

def send(request):
    try:
        phone = request.GET['phone']
        body = request.GET['body']
    except:
        return render(request, 'DEMOAPP/hi.html')
    print('phoneeeeeee-------',phone)
    print('body-------',body)
    from twilio.rest import Client

    # Your Account SID from twilio.com/console
    account_sid = "AC372abf3a0b656698a954db55136d74c7"
    # Your Auth Token from twilio.com/console
    auth_token = "c15d663e88d887cce85aee0e90f21c3d"

    client = Client(account_sid, auth_token)

    try:

        message = client.messages.create(
            to=f"+91{phone}",
            from_="+16146605534",
            body=body)

        print(message.sid)

    except Exception as e:
        return HttpResponse("unable to send msg")

    return render(request,'DEMOAPP/result.html',{'phone':phone,'sid':message.sid})